$(function() {

    $('#drag-img').draggable();


    $('#drag-grid-img').draggable({
        grid: [70,70]
    });


    $('.resize').resizable();

});
